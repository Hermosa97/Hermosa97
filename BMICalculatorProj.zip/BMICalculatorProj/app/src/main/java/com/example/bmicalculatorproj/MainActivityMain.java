package com.example.bmicalculatorproj;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;

public class MainActivityMain extends AppCompatActivity {

    private EditText height;
    private EditText weight;
    private TextView result;
    Button backBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        height = (EditText) findViewById(R.id.height);
        weight = (EditText) findViewById(R.id.weight);
        result = (TextView) findViewById(R.id.result);
        backBtn = findViewById(R.id.backBtn);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivityMain.this, MainActivity.class));
            }
        });

    }

    public void calculateBMI(View v) {
        String heightStr = height.getText().toString();
        String weightStr = weight.getText().toString();

        if (heightStr != null && !"".equals(heightStr)
                && weightStr != null  &&  !"".equals(weightStr)) {
            float heightValue = Float.parseFloat(heightStr) / 100;
            float weightValue = Float.parseFloat(weightStr);

            float bmi = weightValue / (heightValue * heightValue);

            displayBMI(bmi);
        }
    }

    public void displayBMI(float bmi) {
        String bmiLabel = "";
        String risk = "";
        if (Float.compare(bmi, 18.4f) <= 0) {
            bmiLabel = getString(R.string.underweight);
            risk = getString(R.string.malnutrition_risk);
        } else if (Float.compare(bmi, 18.5f) > 0 && Float.compare(bmi, 25f) <= 0) {
            bmiLabel = getString(R.string.normal);
            risk = getString(R.string.low_risk);
        } else if (Float.compare(bmi, 25f) > 0 && Float.compare(bmi, 30f) <= 0) {
            bmiLabel = getString(R.string.overweight);
            risk = getString(R.string.enhanced_risk);
        } else if (Float.compare(bmi, 30f) > 0 && Float.compare(bmi, 35f) <= 0) {
            bmiLabel = getString(R.string.obese_i);
            risk = getString(R.string.medium_risk);
        } else if (Float.compare(bmi, 35f) > 0 && Float.compare(bmi, 40f) <= 0) {
            bmiLabel = getString(R.string.obese_ii);
            risk = getString(R.string.high_risk);
        } else {
            bmiLabel = getString(R.string.obese_iii);
            risk = getString(R.string.very_high_risk);

        }

        bmiLabel = "Your BMI: " + bmi + "\n\n" + bmiLabel + "\n\n" + risk;
        result.setText(bmiLabel);
    }

    public void resetBMI(View v) {
        height.setText(null);
        weight.setText(null);
        result.setText(null);

    }
}


